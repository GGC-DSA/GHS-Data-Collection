
We have completed most features of the application thus far during the 1st and 2nd iterations. Now in the last and 3rd interation, we are focused on polishing the website to make it more aesthetically pleasing and incoporate minor features to enhance the usability of the website. 


-- Features that have not been implement in the application yet. To be worked on (To Do)

    - Selection all function buttons for Find Partners and Partner Submission Form pages

-- The followings have been added to our to do list due to our client's request

    - Partner choice grades

    - Partner to new tab



-- The Projects feature wouldn't be fully functionally be implemented to the website.

    - Projects:
        * The Projects feature hasn't been fully implemented into the project. However, the structure of the project's page has been implemented meaning the pages and sections for it to be placed on are already made via its own page and a section on the teacher profile page.

        There are mock projects that are accessible on the teacher files taken the place of where projects are to be placed under the Projects secion.