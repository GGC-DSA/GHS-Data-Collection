# GreenHealthySchools
GHS project
## Spring 2024
## Team GreenVangard

### Members:

**[Tripp Barker](https://github.com/TrippBarker)**
1. *Lead Programmer💻*
2. *Client Liaison😎*

**[Luis Fabela](https://github.com/Aznitan)**
1. *UI/UX design⚜️*
2. *Programmer/Testing Lead💻*

**[Stephen Wood](https://github.com/StephenWood11)**
1. *Lead Programmer💻*
2. *Team Manager👍*

**[Muhammad Marenah](https://github.com/marenah)**
1. *Data Modeler💻*
2. *Documentation Lead📖/Programmer*


 Description/ About 
In our Software Development II course instructed by Dr. Anca, our objective was to create a web application designed to facilitate connections between Gwinnett County public school teachers and potential partners interested in funding their classroom projects.

 Technologies
A list of all technologies that need to be installed (with links) to be able to run this app
	Node.js and npm - https://docs.npmjs.com/downloading-and-installing-node-js-and-npm
Angular CLI–  https://angular.io/cli
Visual Studio (IDE) - https://code.visualstudio.com/

Installation steps
To install this repo, one must first clone it. Then one must install angular and node.js along with NPM.
Specifically:
Enter in your terminal “git clone https://github.com/GGC-SD/GreenHealthySchools”
This will install a copy of the repository to your local computer via cloning


How to Run
List of commands in order to run the app
In the terminal, Type “npm install” then type “ng serve”. A local host address should be created

Connect to Firebase:
To connect to firebase go into the src folder and create an environments folder with a file called 'environment.ts' with the following:

```TypeScript
/**
 * Copy/Paste firebaseConfig setting from the Firebase project
 * Login into GreenVangard Firebase Account
 * Select GreenHealthySchools Project
 * Open Project Settings
 * Copy/Paste config settings
 */
const firebaseConfig = {
  apiKey: "XXX",
  authDomain: "XXX",
  databaseURL: "XXX",
  projectId: "XXX",
  storageBucket: "XXX",
  messagingSenderId: "XXX",
  appId: "XXX",
  measurementId: "XXX"
};

export const environment = {
  production: false,
  firebase: {
    apiKey: 'XXX',
    authDomain: 'XXX',
    databaseURL: 'XXX',
    projectId: 'XXX',
    storageBucket: 'XXX',
    messagingSenderId: 'XXX',
    appId: 'XXX' 
  }
};
```

List of working features
-	Teacher Profile page:
This page allows the collection of data specific to each teacher to be stored in the database. The purpose of this page is to allow each teacher to have access to their profile after login in
-	Find A Partner page(Partner Search):
The purpose of this page is to be able to search for partners that are on the site’s database. Selecting the appropriate check boxes and clicking submit will show the appropriate partners that match the selected categories.
-	Become A Partner page (Partner Submission From):
The entry point for partner’s to be able to submit partner information to the database. These will be stored as documents in the partner collection.
-	Login/Authentication:
The purpose of the login/authentication function is to enable each specific user who registered to be able to log in and be authenticated to their own unique profile. It was created with Firestore’s Authentication application.