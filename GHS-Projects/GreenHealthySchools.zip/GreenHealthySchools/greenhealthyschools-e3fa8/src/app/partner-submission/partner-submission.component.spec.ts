import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PartnerSubmissionComponent } from './partner-submission.component';

describe('PartnerSubmissionComponent', () => {
  let component: PartnerSubmissionComponent;
  let fixture: ComponentFixture<PartnerSubmissionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PartnerSubmissionComponent],
    });

    fixture = TestBed.createComponent(PartnerSubmissionComponent);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  // Add more test cases as needed
});
