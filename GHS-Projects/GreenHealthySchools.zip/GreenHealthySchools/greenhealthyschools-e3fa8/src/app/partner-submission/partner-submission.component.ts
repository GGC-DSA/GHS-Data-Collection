// partner-submission.component.ts

import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { PartnerService } from '../services/partner.service';
import { Partner } from '../interfaces/partner';
@Component({
  standalone: true,
  imports: [ReactiveFormsModule],
  selector: 'app-partner-submission',
  templateUrl: './partner-submission.component.html',
  styleUrls: [
    './partner-submission.component.css',
    '../app.component.css'
  ]
})
export class PartnerSubmissionComponent implements OnInit {

  partnerService = inject(PartnerService)
  ngOnInit() {
    console.log('PartnerSubmissionForm component initialized');
  }

  partnerSubmit = new FormGroup({
    org: new FormControl(''),
    contactEmail: new FormControl(''),
    contactPhone: new FormControl(''),
    areaOfService: new FormControl(''),
    zipcodesServed: new FormControl(''),
    website: new FormControl(''),
    cleanAir: new FormControl(''),
    cleanWater: new FormControl(''),
    foodWaste: new FormControl(''),
    composting: new FormControl(''),
    recycling: new FormControl(''),
    habitats: new FormControl(''),
    pollinators: new FormControl(''),
    emailNewsletter: new FormControl(''),
    lessonPlans: new FormControl(''),
    lessonSupplies: new FormControl(''),
    techSupport: new FormControl(''),
    speakerVol: new FormControl(''),
    virtualFT: new FormControl(''),
    inpersonFT: new FormControl(''),
    serviceProject: new FormControl(''),
    internships: new FormControl(''),
    scholarships: new FormControl(''),
    studentCapacity: new FormControl(''),
    title1Discount: new FormControl(''),
  })

  focusAreaDataConvert() {
    let focusAreas: string[] = [];
    if (this.partnerSubmit.value.cleanAir) {
      focusAreas.push("Clean Air");
    }
    if (this.partnerSubmit.value.cleanWater) {
      focusAreas.push("Clean Water");
    }
    if (this.partnerSubmit.value.composting) {
      focusAreas.push("Composting");
    }
    if (this.partnerSubmit.value.foodWaste) {
      focusAreas.push("Food Waste");
    }
    if (this.partnerSubmit.value.recycling) {
      focusAreas.push("Recycling");
    }
    if (this.partnerSubmit.value.habitats) {
      focusAreas.push("Habitats (Litter)");
    }
    if (this.partnerSubmit.value.pollinators) {
      focusAreas.push("Pollinators");
    }
    return focusAreas;
  }

  servicesOfferedDataConverter() {
    let servicesOffered: string[] = [];
    if (this.partnerSubmit.value.emailNewsletter) {
      servicesOffered.push("Email/Newsletter");
    }
    if (this.partnerSubmit.value.lessonPlans) {
      servicesOffered.push("Lesson Plans");
    }
    if (this.partnerSubmit.value.lessonSupplies) {
      servicesOffered.push("Lesson Supplies");
    }
    if (this.partnerSubmit.value.techSupport) {
      servicesOffered.push("Tech Support");
    }
    if (this.partnerSubmit.value.speakerVol) {
      servicesOffered.push("Speakers/Volunteers");
    }
    if (this.partnerSubmit.value.virtualFT) {
      servicesOffered.push("Virtual Fieldtrips");
    }
    if (this.partnerSubmit.value.inpersonFT) {
      servicesOffered.push("In-Person Fieldtrips");
    }
    if (this.partnerSubmit.value.serviceProject) {
      servicesOffered.push("Service Project");
    }
    if (this.partnerSubmit.value.internships) {
      servicesOffered.push("Internships");
    }
    if (this.partnerSubmit.value.scholarships) {
      servicesOffered.push("Scholarships");
    }
    return servicesOffered;
  }

  submitPartner() {
    let focusAreas = this.focusAreaDataConvert();
    let servicesOffered = this.servicesOfferedDataConverter();
    this.partnerService.submitPartner(
      this.partnerSubmit.value.org ?? '',
      this.partnerSubmit.value.contactEmail ?? '',
      this.partnerSubmit.value.contactPhone ?? '',
      this.partnerSubmit.value.areaOfService ?? '',
      this.partnerSubmit.value.zipcodesServed ?? '',
      this.partnerSubmit.value.website ?? '',
      this.partnerSubmit.value.studentCapacity ?? '',
      this.partnerSubmit.value.title1Discount ?? '',
      servicesOffered,
      focusAreas,
    )
    this.partnerSubmit.reset();
  }

  async toggleAllServices() {
    const services = document.querySelectorAll<HTMLInputElement>(".service");
    const selectAll = document.querySelector<HTMLInputElement>("#selectAllServices");
    const isChecked = selectAll?.checked ?? false;

    services.forEach(service => {
      if (service !== selectAll) {
        service.checked = isChecked;
        service.dispatchEvent(new Event("change"));
      }
    });
  }

  async toggleAllFAs() {
    const services = document.querySelectorAll<HTMLInputElement>(".fa");
    const selectAll = document.querySelector<HTMLInputElement>("#selectAllFAs");
    const isChecked = selectAll?.checked ?? false;

    services.forEach(service => {
      if (service !== selectAll) {
        service.checked = isChecked;
        service.dispatchEvent(new Event("change"));
      }
    });

  }


}
