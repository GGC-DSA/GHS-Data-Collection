import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { TeachersComponent } from './teacher-profile/teacher-profile.component';
import { LandingComponent } from './landing/landing.component';
import { FindPartnersComponent } from './find-partners/find-partners.component';
import { PartnerProfileComponent } from './partner-profile/partner-profile.component';
import { PartnerSubmissionComponent } from './partner-submission/partner-submission.component';
import { AccountRecoveryComponent } from './account-recovery/account-recovery.component';
import { ProjectSubmissionComponent } from './project-submission/project-submission.component';
import { ProjectDashboardComponent } from './project-dashboard/project-dashboard.component';
import { TeacherRegisterComponent } from './teacher-register/teacher-register.component';
import { UserHelpComponent } from './user-help/user-help.component';

const routes: Routes = [
  { path: 'profile', component: TeachersComponent },
  { path: 'landing', component: LandingComponent },
  { path: 'findpartners', component: FindPartnersComponent },
  { path: 'partnersform', component: PartnerProfileComponent },
  { path: 'partner-submission', component: PartnerSubmissionComponent },
  { path: 'accountRecover', component: AccountRecoveryComponent },
  { path: 'project-submission', component: ProjectSubmissionComponent },
  { path: 'project-dashboard', component: ProjectDashboardComponent },
  { path: 'register', component: TeacherRegisterComponent },
  {path: 'app-user-help', component: UserHelpComponent},
  { path: '', redirectTo: 'landing', pathMatch: 'full' }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
