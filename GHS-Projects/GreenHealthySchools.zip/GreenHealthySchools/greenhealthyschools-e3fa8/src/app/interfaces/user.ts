export interface User {
    userEmail: string;
    email: string;
}
