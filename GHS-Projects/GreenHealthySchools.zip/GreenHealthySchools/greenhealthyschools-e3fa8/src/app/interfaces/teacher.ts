export interface Teacher {
    img: string;
    title: string;
    fName: string;
    mInitial: string;
    lName: string;
    email: string;
    school: string;
    grade: string;
    bio: string;
    projs: string[];
}