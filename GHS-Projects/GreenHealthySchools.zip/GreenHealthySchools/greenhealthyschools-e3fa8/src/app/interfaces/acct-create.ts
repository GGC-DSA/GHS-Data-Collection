export interface AcctCreate {
    title: string;
    firstName: string;
    lastName: string;
    middleInit: string;
    grade: string;
    school: string;
    email: string;
    password: string;
    passConf: string;
}
