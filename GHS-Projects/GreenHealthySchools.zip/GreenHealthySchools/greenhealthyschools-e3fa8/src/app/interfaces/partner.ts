export interface Partner {
    id: string;
    org: string;
    logo: string;
    focusAreas: string[];
    bio: string;
    grades: string[];
    capacity: number;
    cost: number;
    titleOne: boolean;
    teacherRating: number;
    website: string;
    primeContact: string;
    contactEmail: string;
    contactPhone: string;
    areaOfService: string;
    notes: string;
    zipcodesServed: string;
    servicesOffered: string[];
    studentCapacity: string;
    title1Discount: string;
}
