export interface Project {
    name: string;
    img: string[];
    desc: string;
    teacher: string;
    grade: string;
    partners: string[];
}
