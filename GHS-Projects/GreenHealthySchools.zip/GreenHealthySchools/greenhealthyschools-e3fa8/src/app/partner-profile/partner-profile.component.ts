import { Component } from '@angular/core';
import { PARTNERS } from '../mock-partners';
import { NgFor } from '@angular/common';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { Partner } from '../interfaces/partner';
import { StorePartnerService } from '../services/store-partner.service';
import { inject } from '@angular/core';
import firebase from 'firebase/compat/app';
import { doc, getDoc } from 'firebase/firestore';

@Component({
  standalone: true,
  selector: 'app-partnerprofile',
  templateUrl: './partner-profile.component.html',
  styleUrls: [
    './partner-profile.component.css',
    '../app.component.css'
  ],
  imports: [
    NgFor
  ]
})

export class PartnerProfileComponent {
  storePartnerServ = inject(StorePartnerService);
  constructor(private store: AngularFirestore) {}
  partner : Partner = {
    id: "",
    org: "",
    logo: "",
    focusAreas: [],
    bio: "",
    grades: [],
    capacity: 0,
    cost: 0,
    titleOne: false,
    teacherRating: 5,
    website: "",
    primeContact: "",
    contactEmail: "",
    contactPhone: "",
    areaOfService: "",
    notes: "",
    zipcodesServed: "",
    servicesOffered: [],
    studentCapacity: "30",
    title1Discount: "true"
  };
  partnerID = "";
  todo = this.store.collection('todo').valueChanges({ idField: 'org' }) as Observable<Partner[]>;
  ngOnInit() {
    this.partner = (this.storePartnerServ.storedPartner);
  }

  async getPartner(){
    const database = firebase.firestore();
    const snapshot = await firebase.firestore().collection('partner').get();
    const firebaseDoc = doc(database, "partner", this.partnerID);
    const docSnap = await getDoc(firebaseDoc);
    const data = docSnap.data() as Partner;
    this.partner = data;
    console.log(data);
  }
}
