import { Component } from '@angular/core';


@Component({
  selector: 'app-project-submission',
  templateUrl: './project-submission.component.html',
  styleUrl: './project-submission.component.css',
  
})
export class ProjectSubmissionComponent {
  toggleSection(sectionID:string) {
    var section = document.getElementById(sectionID) as HTMLDivElement;
    section.style.display = (section.style.display === 'none' || section.style.display === '') ? 'block' : 'none';
  }



  

}
