import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../services/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  standalone: true,
  imports:[ReactiveFormsModule],
  selector: 'app-account-recovery',
  templateUrl: './account-recovery.component.html',
  styleUrls: ['account-recovery.component.css',
  '../app.component.css'
  ]
})
export class AccountRecoveryComponent {
  route: ActivatedRoute = inject(ActivatedRoute)
  userService = inject(UserService)
  accountRecover= new FormGroup({

  })
}
