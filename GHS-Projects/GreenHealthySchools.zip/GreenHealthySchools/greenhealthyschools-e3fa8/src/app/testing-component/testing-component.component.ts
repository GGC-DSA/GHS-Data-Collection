import { Component } from '@angular/core';

@Component({
  selector: 'app-testing-component',
  templateUrl: './testing-component.component.html',
  styleUrl: './testing-component.component.css'
})
export class TestingComponentComponent {

}
