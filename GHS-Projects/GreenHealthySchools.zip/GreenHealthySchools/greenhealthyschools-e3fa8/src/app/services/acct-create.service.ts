import { Injectable } from '@angular/core';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth, createUserWithEmailAndPassword, sendSignInLinkToEmail, isSignInWithEmailLink } from "firebase/auth";

@Injectable({
  providedIn: 'root'
})
export class AcctCreateService {
  constructor() { }
  async createAcct(email: string){
    const auth = getAuth();
    const actionCodeSettings = {
      url: 'https://greenhealthyschools-e3fa8.web.app/register',
      handleCodeInApp: true,
      email: "email"
    }
    sendSignInLinkToEmail(auth, email, actionCodeSettings).then(() => {
      window.localStorage.setItem('emailForSignIn', email);
    }).catch((error) => {
      const errorCode = error.code;
      const errorMsg = error.message;
    })
  }
  async submitAcct(title: string, firstName: string, lastName: string, middleInit: string, grade: string, school: string, email: string, password: string, passwordCongf: string) {
    const auth = getAuth();
    createUserWithEmailAndPassword(auth, email, password).then((userCredential) => {
      const user = userCredential.user;
      firebase.firestore().collection('teacher').doc(user.uid).set({
        img: 'gs://greenhealthyschools-e3fa8.appspot.com/profileImgs/teacher.jpg',
        title: title,
        fName: firstName,
        mInitial: middleInit,
        lName: lastName,
        email: email,
        school: school,
        grade: grade,
        bio: '',
        projs: []
      })
    }).catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.errorMessage
      console.log(errorMessage);
    })
  }
}
