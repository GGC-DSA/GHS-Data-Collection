import { Injectable } from '@angular/core';
import { Partner } from '../interfaces/partner';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth } from 'firebase/auth';
@Injectable({
  providedIn: 'root'
})
export class PartnerService {

  constructor() { }

  submitPartner(org:string, contactEmail:string, contactPhone:string, areaOfService:string, zipcodesServed:string,
    website:string, studentCapacity:string, title1Discount:string, servicesOffered:string[], focusAreas:string[]){
      const auth = getAuth();
      firebase.firestore().collection('pendingPartner').add({
        org:org,
        contactEmail: contactEmail,
        contactPhone: contactPhone,
        areaOfService: areaOfService,
        zipcodesServed: zipcodesServed,
        website: website,
        studentCapacity: studentCapacity,
        title1Discount: title1Discount,
        servicesOffered: servicesOffered,
        focusAreas: focusAreas,
      })
  }
}
