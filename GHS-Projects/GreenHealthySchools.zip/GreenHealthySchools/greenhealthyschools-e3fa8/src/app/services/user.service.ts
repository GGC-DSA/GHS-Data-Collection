import { Injectable } from '@angular/core';
import { LandingComponent } from '../landing/landing.component';
import { User } from '../interfaces/user';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, updateCurrentUser } from 'firebase/auth';
import { signOut } from 'firebase/auth';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }
  auth = getAuth();
  submitLogIn(userEmail: string, password: string){
    this.auth = getAuth();
    signInWithEmailAndPassword(this.auth, userEmail, password).then((userCredential) => {
      const user = userCredential.user;
      updateCurrentUser(this.auth, user);
    }).catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
    });
  }
  getUID() {
    var uid = this.auth.currentUser?.uid;
    return uid;
  }
  userSignOut(){
    signOut(this.auth);
  }
}
