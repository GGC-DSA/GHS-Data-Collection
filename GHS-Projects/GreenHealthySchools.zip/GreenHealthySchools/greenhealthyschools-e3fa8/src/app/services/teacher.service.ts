import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { getAuth } from 'firebase/auth';

import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {
  
  constructor() { }
  auth = getAuth();
  getUID(){
    this.auth = getAuth();
    console.log(this.auth.currentUser?.uid);
    const uid = this.auth.currentUser?.uid;
    return uid;
  }
}
