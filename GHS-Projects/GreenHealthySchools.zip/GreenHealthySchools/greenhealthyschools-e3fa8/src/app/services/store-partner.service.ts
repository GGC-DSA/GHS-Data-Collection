import { Injectable } from '@angular/core';
import { Partner } from '../interfaces/partner';

@Injectable({
  providedIn: 'root'
})
export class StorePartnerService {

  constructor() { }
  storedPartner : Partner = {
    id: "",
    org: "",
    logo: "",
    focusAreas: [],
    bio: "",
    grades: [],
    capacity: 0,
    cost: 0,
    titleOne: false,
    teacherRating: 5,
    website: "",
    primeContact: "",
    contactEmail: "",
    contactPhone: "",
    areaOfService: "",
    notes: "",
    zipcodesServed: "",
    servicesOffered: [],
    studentCapacity: "30",
    title1Discount: "true"
  };

  setVar(partner:Partner){
    this.storedPartner = partner;
  }
}
