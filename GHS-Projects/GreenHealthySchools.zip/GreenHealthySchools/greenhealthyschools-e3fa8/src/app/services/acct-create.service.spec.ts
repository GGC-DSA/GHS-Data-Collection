import { TestBed } from '@angular/core/testing';

import { AcctCreateService } from './acct-create.service';

describe('AcctCreateService', () => {
  let service: AcctCreateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AcctCreateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
