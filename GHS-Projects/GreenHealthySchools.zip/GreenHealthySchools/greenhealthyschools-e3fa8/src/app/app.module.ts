import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { environment } from '../environments/environment';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireDatabaseModule } from '@angular/fire/compat/database'
import { AngularFireStorageModule } from '@angular/fire/compat/storage'
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FindPartnersComponent } from './find-partners/find-partners.component';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { NewProjectComponent } from './new-project/new-project.component';
import { ProjectDashboardComponent } from './project-dashboard/project-dashboard.component';
import { ProjectSubmissionComponent } from './project-submission/project-submission.component';

@NgModule({
  declarations: [
    AppComponent,
    FindPartnersComponent,
    NewProjectComponent,
    ProjectDashboardComponent,
    ProjectSubmissionComponent,
  ],
  imports: [
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    AngularFireStorageModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    provideFirebaseApp(() => initializeApp( environment.firebase )),
    provideFirestore(() => getFirestore())
  ],
  providers: [AngularFireModule],
  bootstrap: [AppComponent]
})
export class AppModule {}
