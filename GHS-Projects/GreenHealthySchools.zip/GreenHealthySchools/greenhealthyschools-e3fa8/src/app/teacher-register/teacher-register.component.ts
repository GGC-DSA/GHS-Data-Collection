import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { NgFor } from '@angular/common';
import { UserService } from '../services/user.service';
import { AcctCreateService } from '../services/acct-create.service';
import { Router, RouterModule } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth, isSignInWithEmailLink } from 'firebase/auth';
import { onAuthStateChanged } from 'firebase/auth';

@Component({
  selector: 'app-teacher-register',
  standalone: true,
  templateUrl: './teacher-register.component.html',
  imports: [ ReactiveFormsModule, RouterModule, NgFor],
  styleUrls: [
    './teacher-register.component.css',
    '../app.component.css'
  ]
})

export class TeacherRegisterComponent {
  constructor(private router: Router){};
  route: ActivatedRoute= inject(ActivatedRoute)
  schools : any [] = [];
  ngOnInit() {
    this.getSchools();
    const auth = getAuth();
    onAuthStateChanged(auth, async (user) => {
      if (isSignInWithEmailLink(auth, window.location.href)) {
        const loading = document.querySelector("#loadingMsg");
        loading?.classList.toggle("hidden");
        const loginForm = document.querySelector("#signUpForm");
        loginForm?.classList.toggle("hidden");
      } else {
        this.router.navigate(['/landing']);
      }
    })
  }
  async getSchools(){
    const snapshot = await firebase.firestore().collection('school').get();
    snapshot.forEach((doc) => this.schools.push((doc.data())));
    this.schools.sort((a, b) => a.name.localeCompare(b.name))
  }
  userService = inject(UserService);
  acctService = inject(AcctCreateService);
  createForm = new FormGroup({
    title: new FormControl(''),
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    middleInit: new FormControl(''),
    grade: new FormControl(''),
    school: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    passCOnf: new FormControl(''),
  })
  submitAcct(){
    this.acctService.submitAcct(
      this.createForm.value.title ?? '',
      this.createForm.value.lastName ?? '',
      this.createForm.value.firstName ?? '',
      this.createForm.value.middleInit ?? '',
      this.createForm.value.grade ?? '',
      this.createForm.value.school ?? '',
      this.createForm.value.email ?? '',
      this.createForm.value.password ?? '',
      this.createForm.value.passCOnf ?? '',
    )
  }
}
