import { Component, OnInit } from '@angular/core';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, updateCurrentUser, onAuthStateChanged } from 'firebase/auth';
import { signOut } from 'firebase/auth';
import { environment } from '../environments/environment';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'

}) 
export class AppComponent {
  title = 'GreenHealthySchools';
  ngOnInit() {
    const firebaseConfig = environment.firebase,
    app = firebase.initializeApp(firebaseConfig),
    auth = getAuth();
    onAuthStateChanged(auth, async (user) => {
      if (user?.uid){
        const loginNav = (document.querySelector("#loginNav") as HTMLLinkElement);
        if (loginNav){
          loginNav.innerHTML = "LOGOUT";
        }
      }
    })
  }
  userSignOut(){
    const loginNav = (document.querySelector("#loginNav") as HTMLLinkElement);
    if (loginNav && loginNav?.innerHTML == "LOGOUT"){
      loginNav.innerHTML = "LOGIN";
      signOut(getAuth());
    }
  }

}
