import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { NgFor } from '@angular/common';
import { UserService } from '../services/user.service';
import { AcctCreateService } from '../services/acct-create.service';
import { Router, RouterModule } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { onAuthStateChanged } from 'firebase/auth';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule, NgFor],
  templateUrl: './landing.component.html',
  styleUrls:[
    './landing.component.css',
    '../app.component.css',
  ],
}
)
export class LandingComponent {
  emailRegex = new RegExp(/^[A-Za-z0-9_!#$%&'*+\/=?`{|}~^.-]+(@ggc.edu|@gcpsk12.org)+$/, "i");
  constructor(private router: Router){};
  route: ActivatedRoute= inject(ActivatedRoute)
  userService = inject(UserService)
  loginForm = new FormGroup({
    userEmail: new FormControl(''),
    password: new FormControl(''),
  })

  acctSevice = inject(AcctCreateService)
  createForm = new FormGroup({
    title: new FormControl(''),
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    middleInit: new FormControl(''),
    grade: new FormControl(''),
    school: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    passCOnf: new FormControl(''),
  })

  submitLogIn(){
    this.userService.submitLogIn(
      this.loginForm.value.userEmail ?? '',
      this.loginForm.value.password ?? '',
    )
    const uid = this.userService.getUID();
    console.log(uid);
    if (uid == undefined){
      const badLoginMsg = (document.querySelector("#badLoginMsg") as HTMLParagraphElement);
      if (badLoginMsg){
        badLoginMsg?.classList.remove("hidden");
      }
    }
  }

  toggleHidden(idOne: string, idTwo: string){
    const login = document.querySelector(idOne);
    const signUp = document.querySelector(idTwo);
    const maincontainer = document.querySelector(".maincontainer");
    maincontainer?.classList.toggle("loginCard");
    maincontainer?.classList.toggle("signupCard");
    login?.classList.toggle("hidden");
    signUp?.classList.toggle("hidden");
    signUp?.classList.toggle("signupSize");
  }

  createAcct(){
    this.acctSevice.createAcct(
      this.createForm.value.email ?? ''
    )
  }

  submitAcct(){
    this.acctSevice.submitAcct(
      this.createForm.value.title ?? '',
      this.createForm.value.lastName ?? '',
      this.createForm.value.firstName ?? '',
      this.createForm.value.middleInit ?? '',
      this.createForm.value.grade ?? '',
      this.createForm.value.school ?? '',
      this.createForm.value.email ?? '',
      this.createForm.value.password ?? '',
      this.createForm.value.passCOnf ?? '',
    )
  }

  checkEmails(){
    const email = (document.querySelector("#emailInput") as HTMLInputElement).value;
    const confEmail = (document.querySelector("#confEmailInput") as HTMLInputElement).value;
    if (email == confEmail && this.emailRegex.test(email)){
      const submitBTN = document.querySelector("#submitEmailbtn") as HTMLButtonElement;
      submitBTN.classList.remove('disabled');
      submitBTN.removeAttribute('disabled');
    } else {
      const submitBTN = document.querySelector("#submitEmailbtn") as HTMLButtonElement;
      submitBTN.classList.add('disabled');
      submitBTN.setAttribute('disabled', 'true');
    }
  }

  schools : any [] = [];
  ngOnInit() {
    this.getSchools();
    const auth = getAuth();
    onAuthStateChanged(auth, async (user) => {
      if (user?.uid){
        this.router.navigate(['/profile']);
      }
    })
  }
  async getSchools(){
    const snapshot = await firebase.firestore().collection('school').get();
    snapshot.forEach((doc) => this.schools.push((doc.data())));
    this.schools.sort((a, b) => a.name.localeCompare(b.name))
  }
}
