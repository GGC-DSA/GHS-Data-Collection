export class FindPartnersForm {
    selectedGrade : number;
    emailNewsLetter: boolean;
    lessonPlans : boolean;
    lessonSupplies : boolean;
    techSupport :boolean;
    speakerVol : boolean;
    virtualFT : boolean;
    inpersonFT : boolean;
    serviceProject : boolean;
    internships : boolean;
    scholarships : boolean;
    cleanAir : boolean;
    cleanWater : boolean;
    foodWaste : boolean;
    composting : boolean;
    recycling : boolean;
    habitats : boolean;
    pollinators : boolean;


    constructor() {
    this.selectedGrade = 1;
    this.emailNewsLetter = false;
    this.lessonPlans =false;
    this.lessonSupplies=false;
    this.techSupport=false;
    this.speakerVol=false;
    this.virtualFT=false;
    this.inpersonFT=false;
    this.serviceProject=false;
    this.internships=false;
    this.scholarships=false;
    this.cleanAir=false;
    this.cleanWater=false;
    this.foodWaste=false;
    this.composting=false;
    this.recycling=false;
    this.habitats=false;
    this.pollinators=false;
  }
}

