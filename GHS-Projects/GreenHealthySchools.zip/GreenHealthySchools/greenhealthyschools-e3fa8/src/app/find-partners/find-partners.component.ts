import { Component, inject } from '@angular/core';
import { PARTNERS } from '../mock-partners';
import { FindPartnersForm } from './find-partners.model';
import firebase from 'firebase/compat/app';
import { StorePartnerService } from '../services/store-partner.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { Partner } from '../interfaces/partner';

@Component({
  selector: 'app-find-partners',
  templateUrl: './find-partners.component.html',
  styleUrls: [
    './find-partners.component.css',
    '../app.component.css'
  ],
})
export class FindPartnersComponent {
  findPartnersForm: FindPartnersForm = new FindPartnersForm();
  partners: any[] = [];
  filterPartners: any[] = [];
  grades: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  // ngOnInit Initialize the page with this fucntion(s).
  constructor(private router: Router) { };
  route: ActivatedRoute = inject(ActivatedRoute)
  storePartnerServ = inject(StorePartnerService);

  // flag to keep track wich partners array display first example we want to display to the user all partners NOT filtered
  // then when it filters we need to uptade with the filtered array so we need this flag to do that 
  formSubmitted: boolean = false;
  //then a new array comes which we use to update the partners array or the filterpartners array 
  displayPartners: any[] = [];


  async filterSubmitForm() {
    //submition logic in here
    //filter partners based on selected grade and properties
    const selectedGrade = this.findPartnersForm.selectedGrade;
    const emailNewsletter = this.findPartnersForm.emailNewsLetter;
    const lessonPlans = this.findPartnersForm.lessonPlans;
    const lessonSupplies = this.findPartnersForm.lessonSupplies;
    const techSupport = this.findPartnersForm.techSupport;
    const speakerVol = this.findPartnersForm.speakerVol;
    const virtualFT = this.findPartnersForm.virtualFT;
    const inpersonFT = this.findPartnersForm.inpersonFT;
    const serviceProject = this.findPartnersForm.serviceProject;
    const internships = this.findPartnersForm.internships;
    const scholarships = this.findPartnersForm.scholarships;
    const cleanAir = this.findPartnersForm.cleanAir;
    const cleanWater = this.findPartnersForm.cleanWater;
    const foodWaste = this.findPartnersForm.foodWaste;
    const composting = this.findPartnersForm.composting;
    const recycling = this.findPartnersForm.recycling;
    const habitats = this.findPartnersForm.habitats;
    const pollinators = this.findPartnersForm.pollinators;

    //  testing if checkbozxes are checked 
    // console.log('Checkbox values:');
    // console.log('Email Newsletter:', emailNewsletter);
    // console.log('Lesson Plans:', lessonPlans);
    // console.log('Lesson Supplies:', lessonSupplies);
    // console.log('Clean Air:', cleanAir);
    //compare partners with the checkboxes then if they are true push them into teh filterpartners lastly push to the partner result
    this.filterPartners = [];
    this.partners.forEach(partner => {
      //if (partner.grade === selectedGrade){
      console.log('Partners:', partner)
      if (
        (emailNewsletter && partner.servicesOffered.includes('Email Newsletter')) ||
        (lessonPlans && partner.servicesOffered.includes('Lesson Plans')) ||
        (lessonSupplies && partner.servicesOffered.includes('Lesson Supplies')) ||
        (techSupport && partner.servicesOffered.includes('Technical Support')) ||
        (speakerVol && partner.servicesOffered.includes('Speaker/Volunteer')) ||
        (virtualFT && partner.servicesOffered.includes('Virtual Field Trips')) ||
        (inpersonFT && partner.servicesOffered.includes('In-person Field Trips')) ||
        (serviceProject && partner.servicesOffered.includes('Service Projects')) ||
        (internships && partner.servicesOffered.includes('Internships')) ||
        (scholarships && partner.servicesOffered.includes('Scholarships')) ||
        (cleanAir && partner.focusAreas.includes('Clean Air')) ||
        (cleanWater && partner.focusAreas.includes('Clean Water')) ||
        (foodWaste && partner.focusAreas.includes('Food Waste')) ||
        (composting && partner.focusAreas.includes('Composting')) ||
        (recycling && partner.focusAreas.includes('Recycling')) ||
        (habitats && partner.focusAreas.includes('Habitats')) ||
        (pollinators && partner.focusAreas.includes('Pollinators'))
      ) {
        this.filterPartners.push(partner);
      }
      //}
    });

    //checking if filtered partners array is getting populated
    console.log('Filtered partners:', this.filterPartners);
    //console.log('Partners pull from the DB firestore:', this.partners);
    this.displayPartners = this.filterPartners;
    this.formSubmitted = true;
  }

  ngOnInit() {
    this.getPartners();
    // set the display partenrs with all the partners form the firebase on the oninit that way when a user opens the page can see all tghe partners NOT filtered but when it submits the filters now updates tghe partners
    this.displayPartners = this.partners;
    this.sortProjects();
  }

  // all partners form the DB are pull and store to the parrner array.
  async getPartners() {
    const snapshot = await firebase.firestore().collection('partner').get();
    snapshot.forEach((doc) => this.partners.push((doc.data())));
  }

  async routeToPartner(partner: Partner) {
    this.storePartnerServ.setVar(partner);
    this.router.navigate(['/partnersform']);
  }

  async toggleFilter() {
    const partnerFind = document.querySelector("#partnerFind");
    partnerFind?.classList.toggle("partnerHidden");
    partnerFind?.classList.toggle("partnerShowing");
  }

  async toggleAllServices() {
    const services = document.querySelectorAll<HTMLInputElement>(".service");
    const selectAll = document.querySelector<HTMLInputElement>("#selectAllServices");
    const isChecked = selectAll?.checked ?? false;

    services.forEach(service => {
      if (service !== selectAll) {
        service.checked = isChecked;
        service.dispatchEvent(new Event("change"));
      }
    });
  }

  async toggleAllFAs() {
    const services = document.querySelectorAll<HTMLInputElement>(".fa");
    const selectAll = document.querySelector<HTMLInputElement>("#selectAllFAs");
    const isChecked = selectAll?.checked ?? false;

    services.forEach(service => {
      if (service !== selectAll) {
        service.checked = isChecked;
        service.dispatchEvent(new Event("change"));
      }
    });

  }


  sortProjects() {
    const selectBox = document.getElementById("sortby") as HTMLSelectElement;
    const selectedValue = selectBox.value;

    if (selectedValue === "orgASC") {
      this.displayPartners.sort((a, b) => a.org.localeCompare(b.org));
    } else if (selectedValue === "orgDSC") {
      this.displayPartners.sort((a, b) => b.org.localeCompare(a.org));
    }
  }
}


