import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FindPartnersComponent } from './find-partners.component';

describe('FindPartnersComponent', () => {
  let component: FindPartnersComponent;
  let fixture: ComponentFixture<FindPartnersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FindPartnersComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FindPartnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
