import { Component } from '@angular/core';

@Component({
  selector: 'app-user-help',
  templateUrl: './user-help.component.html',
  styleUrl: './user-help.component.css'
})
export class UserHelpComponent {

}
