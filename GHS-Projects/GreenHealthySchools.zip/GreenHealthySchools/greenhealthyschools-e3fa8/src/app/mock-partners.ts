import { Partner } from "./interfaces/partner";

export const PARTNERS: Partner[] = [
    {
        id: "",
        org: "Captain Planet Foundation",
        logo: "assets/placeholderimg/partner2.jpg",
        focusAreas: ["Clean Air", "Clean Water", "Food Waste", "Gardening", "Habitats", "Pollinators"],
        bio: 'Based on the critically-acclaimed animated series Captain Planet and the Planeteers, Captain Planet Foundation (CPF) was co-founded in 1991 by media mogul Ted Turner and producer Barbara Pyle as a corporate foundation of TBS. Captain Planet Foundation prides itself on efficient spending to maximize investment in support of our mission - engaging and empowering kids to become the next generation of Planeteers.',
        grades: ["K", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th"],
        capacity: 30,
        cost: 0.00,
        titleOne: true,
        teacherRating: 5,
        website: "https://captainplanetfoundation.org/",
        primeContact: "Primary Contact Name",
        contactEmail: "contact@CPF.com",
        contactPhone: "555-888-8888",
        areaOfService: "National",
        notes: "ecoSTEM kits available",
        zipcodesServed: "",
        servicesOffered: ["Lesson Plans", "Lesson Supplies", "Technical Support"],
        studentCapacity: "30",
        title1Discount: "true"
    }
]