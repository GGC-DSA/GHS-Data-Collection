import { Component, Input, OnInit, inject } from '@angular/core';
import { Teacher } from '../interfaces/teacher';
import { ProjectcardComponent } from '../project-card/project-card.component';
import { NgFor } from '@angular/common';
import { RouterModule } from '@angular/router';
import firebase from 'firebase/compat/app';
import 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { ref, getStorage, getDownloadURL, uploadBytesResumable } from 'firebase/storage';
import { UserService } from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-teachers',
  templateUrl: './teacher-profile.component.html',
  styleUrls: [
    './teacher-profile.component.css',
    '../app.component.css'
  ],
  imports: [
    ProjectcardComponent, 
    NgFor,
    RouterModule
  ]
})

export class TeachersComponent {
  schools : any [] = [];
  constructor(private router: Router){};
  route: ActivatedRoute= inject(ActivatedRoute)
  userService = inject(UserService);
  teacher : Teacher = {
    img: "assets/placeholderimg/placeholder.jpg",
    title: "",
    fName: "",
    mInitial: "",
    lName: "",
    email: "",
    school: "",
    grade: "",
    bio: "",
    projs: [""]
  }
  editProfile(){
    const flipcard = document.querySelector("#flipcard-inner");
    flipcard?.classList.toggle("rotate");
    console.log("edit profile");
  }
  ngOnInit(){
    this.getTeacher();
    this.getSchools();
  }
  async getSchools(){
    const snapshot = await firebase.firestore().collection('school').get();
    this.schools.push({name:"aaaaaaa"});
    snapshot.forEach((doc) => this.schools.push((doc.data())));
    this.schools.sort((a, b) => a.name.localeCompare(b.name));
    this.schools[0]={name:"All Schools"};
  }
  auth = getAuth();
  async getTeacher(){
    onAuthStateChanged(this.auth, async (user) => {
      console.log(this.userService.getUID());
      if (user){
        const database = firebase.firestore();
      console.log(this.auth.currentUser?.uid);
        if (this.auth.currentUser?.uid == undefined){
          console.log("undefined user");
        } else {
          const firebaseDoc = doc(database, "teacher", this.auth.currentUser?.uid);
          const docSnap = await getDoc(firebaseDoc);
          const data = docSnap.data() as Teacher;
          console.log(data);
          this.teacher = data;
          const storage = getStorage();
          const gsRef = ref(storage, data.img);
          const titleInput = (document.querySelector("#titleInput") as HTMLSelectElement);
          for (let i = 0; i < titleInput.options.length; i++){
            if (titleInput.options[i].value == this.teacher.title){
              titleInput.options[i].selected = true;
            }
          }
          const schoolInput = (document.querySelector("#schoolInput") as HTMLSelectElement);
          for (let i = 0; i < schoolInput.options.length; i++){
            if (schoolInput.options[i].value == this.teacher.school){
              schoolInput.options[i].selected = true;
            }
          }
          const gradeInput = (document.querySelector("#gradeInput") as HTMLSelectElement);
          for (let i = 0; i < gradeInput.options.length; i++){
            if (gradeInput.options[i].value == this.teacher.grade){
              gradeInput.options[i].selected = true;
            }
          }
          const lNameInput = document.querySelector("#lNameInput");
          lNameInput?.setAttribute("value", this.teacher.lName);
          const mInitial = document.querySelector("#mInitialInput");
          mInitial?.setAttribute("value", this.teacher.mInitial);
          const fNameInput = document.querySelector("#fNameInput");
          fNameInput?.setAttribute("value", this.teacher.fName);
          const preferredCBs = (document.querySelectorAll(".preferredCB"));
          for (let i = 0; i < this.teacher.projs.length; i++){
            for (let j = 0; j < preferredCBs.length; j++){
              let checkbox = preferredCBs[j] as HTMLInputElement;
              if (checkbox.value == this.teacher.projs[i]){
                checkbox.setAttribute("checked", "true");
              }
            }
          }
          const bioInput = (document.querySelector("#bioInput") as HTMLTextAreaElement);
          bioInput.textContent = this.teacher.bio;
          getDownloadURL(gsRef).then((url) => {
            this.teacher.img = url;
          })
          const loadingMsg = document.querySelector('#loading') as HTMLDivElement;
          loadingMsg.classList.add("hidden");
          const profile = document.querySelector('#profile') as HTMLDivElement;
          profile.classList.remove("hidden");
        }
      } else {
        this.router.navigate(['/landing']);
      }
    })
  }
  updateProfile(){
    const preferredCBs = (document.querySelectorAll(".preferredCB"));
    let preferredList: string[] = [];
    const metadata = {
      contentType: 'image/jpeg'
    }
    for (let i = 0; i < preferredCBs.length; i++){
      let checkbox = preferredCBs[i] as HTMLInputElement;
      if (checkbox.checked){
        preferredList.push(checkbox.value);
      }
    }
    const title = (document.querySelector("#titleInput") as HTMLSelectElement).value;
    const lNameInput = (document.querySelector("#lNameInput") as HTMLInputElement).value;
    const mInitial = (document.querySelector("#mInitialInput") as HTMLInputElement).value;
    const fNameInput = (document.querySelector("#fNameInput") as HTMLInputElement).value;
    const bioInput = (document.querySelector("#bioInput") as HTMLTextAreaElement).value;
    const schoolInput = (document.querySelector("#schoolInput") as HTMLSelectElement).value;
    const gradeInput = (document.querySelector("#gradeInput") as HTMLSelectElement).value;
    firebase.firestore().collection('teacher').doc(this.auth.currentUser?.uid).update({
      title: title,
      lName: lNameInput,
      mInitial: mInitial,
      fName: fNameInput,
      grade: gradeInput,
      school: schoolInput,
      bio: bioInput, 
      projs: preferredList
    });
    const flipcard = document.querySelector("#flipcard-inner");
    flipcard?.classList.toggle("rotate");
    this.getTeacher();
    const image = document.querySelector("#profileImgInput") as HTMLInputElement;
    const storage = getStorage();
    const storageRef = ref(storage, 'profileImgs/' + this.auth.currentUser?.uid);
    if (image.files && image.files?.length > 0){
      const uploadTask = uploadBytesResumable(storageRef, image.files[0], metadata);
      uploadTask.on('state_changed', (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("upload is " + progress + "% done");
        switch (snapshot.state){
          case 'paused':
            console.log("upload is paused");
            break;
          case 'running':
            console.log('upload in progress');
            break;
        }
      },
      (error) => {
        switch (error.code){
          case 'storage/unauthorized':
            console.log("User doesn't have permission to access the object");
            break;
          case 'storage/canceled':
            console.log("User canceled the upload");
            break;
        }
      },
      () => {
        console.log("upload complete");
        firebase.firestore().collection('teacher').doc(this.auth.currentUser?.uid).update({
          img: 'gs://greenhealthyschools-e3fa8.appspot.com/profileImgs/' + this.auth.currentUser?.uid,
        });
        this.getTeacher();
      })
    }
  }
}