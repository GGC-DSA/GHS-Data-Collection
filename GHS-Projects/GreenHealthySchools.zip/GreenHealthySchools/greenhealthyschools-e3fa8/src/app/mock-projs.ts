import { Project } from "./interfaces/project"

export const PROJECTS: Project[] = [
  {
    name: "Project Title (32 char limit)",
    img: ["assets/placeholderimg/garden2.jpg", "assets/placeholderimg/garden1.jpg"],
    desc: "Here a teacher can write a short discriptioon detailing a project. This discription is limited to 200 characters. Suspendisse lobortis nisl a lacus consectetur, eget ante hendrerit. In consectetur.",
    teacher: "Ti. Fname M Lastname",
    grade: "8th",
    partners: ["Adopt-a-Road"]
  }, 
  {
    name: "Observing Our Local Pollinators",
    img: ["assets/placeholderimg/pollinator.jpg"],
    desc: "Elementry students observe and marvel at the precision with which butterflies navigate from flower to flower, transferring pollen and facilitating the essential process of pollination.",
    teacher: "Ti. Fname M Lastname",
    grade: "8th",
    partners: ["Adopt-a-Stream"]
  },
  {
    name: "Measuring Water Quality",
    img: ["assets/placeholderimg/stream.jpg"],
    desc: "Students embark on an educational adventure as they explore and measure the water quality of a nearby stream. Armed with curiosity, these young minds engage in hands-on learning to understand the environmental health of their local ecosystem.",
    teacher: "Ti. Fname M Lastname",
    grade: "8th",
    partners: ["Adopt-a-Stream"]
  }
]