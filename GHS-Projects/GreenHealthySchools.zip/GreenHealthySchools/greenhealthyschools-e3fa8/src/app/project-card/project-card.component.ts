import { Component } from '@angular/core';
import { PROJECTS } from '../mock-projs';
import { NgFor } from '@angular/common';

@Component({
  standalone: true,
  imports: [
    NgFor
  ],
  selector: 'app-projects',
  templateUrl: './project-card.component.html',
  styleUrl: './project-card.component.css'
})

export class ProjectcardComponent {
  projects = PROJECTS;
}