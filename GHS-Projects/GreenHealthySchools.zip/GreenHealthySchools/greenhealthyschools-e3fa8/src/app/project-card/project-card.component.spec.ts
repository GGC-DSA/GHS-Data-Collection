import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectcardComponent } from './project-card.component';

describe('ProjectcardComponent', () => {
  let component: ProjectcardComponent;
  let fixture: ComponentFixture<ProjectcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProjectcardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProjectcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
